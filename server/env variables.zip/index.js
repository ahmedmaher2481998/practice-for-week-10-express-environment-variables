console.log(process.env.NODE_ENV);
// NODE_ENV="production" node index.js
